var btn_add = document.querySelector('.add');
var btn_less = document.querySelector('.less');
btn_add.addEventListener('click', updateBtn_add);
btn_less.addEventListener('click', updateBtn_less);

function updateBtn_add(){
    nb = (nb + 1) % length;
    importation()
}
function updateBtn_less(){
    if (nb == 0){
        nb = length;
    }
    nb = nb - 1;
    importation()
}
function httpGet(theUrl)
            {
                    var xmlHttp = new XMLHttpRequest();
                    xmlHttp.open( "GET", theUrl, false ); // false for synchronous request
                    xmlHttp.send( null );
                    return xmlHttp.responseText;
}

var data_set = JSON.parse(httpGet("https://valorant-api.com/v1/agents"));
var data_set = data_set['data'];
chaine = [];
wanted_data = ["displayName", "description", "bustPortrait", "background", "role"];
for (variable in data_set) {
    perso = [];
    for (element in data_set[variable]){
        if (wanted_data.includes(element)){
        perso.push(data_set[variable][element]);
        }
        if (element == 'isPlayableCharacter' & data_set[variable][element]){
chaine.push(perso)
        }
    }
}
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}
length = chaine.length
var nb = getRandomInt(length)
importation()

function importation(){
    console.log(chaine[nb][4]['displayIcon'])
    document.getElementById("main_left").innerHTML = "<img src=" + chaine[nb][4]['displayIcon'] + "> \
    <p>" + chaine[nb][4]['displayName'] + "<br>" + chaine[nb][4]['description'] + "</p>";
    document.getElementById("main_right").innerHTML = "<p> " + chaine[nb][1] + "</p>";
    document.getElementById("add_img").innerHTML = "<img src=" + chaine[nb][2] + " class='above'> \
    <img src=" + chaine[nb][3] + " class='behind'>";
    document.getElementById("main_bot").innerHTML = "<h3>" + chaine[nb][0] + "</h3>";}