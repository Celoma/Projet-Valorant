var btn_add = document.querySelector('.add');
var btn_less = document.querySelector('.less');
btn_add.addEventListener('click', updateBtn_add);
btn_less.addEventListener('click', updateBtn_less);

function updateBtn_add(){
    nb = (nb + 1) % length;
    document.getElementById("testing").innerHTML = '<img src=' + chaine[nb][0][2] + '>';
}
function updateBtn_less(){
    if (nb == 0){
        nb = length;
    }
    nb = nb - 1;
    document.getElementById("testing").innerHTML = '<img src=' + chaine[nb][0][2] + '>';
}
function httpGet(theUrl)
            {
                    var xmlHttp = new XMLHttpRequest();
                    xmlHttp.open( "GET", theUrl, false ); // false for synchronous request
                    xmlHttp.send( null );
                    return xmlHttp.responseText;
}

var data_set = JSON.parse(httpGet("https://valorant-api.com/v1/agents"));
var data_set = data_set['data'];
chaine = [];
wanted_data = ["displayName", "description", "bustPortrait", "background"];
for (variable in data_set) {
    perso = [];
    for (element in data_set[variable]){
        if (wanted_data.includes(element)){
        perso.push(data_set[variable][element]);
        }
        if (element == 'isPlayableCharacter' & data_set[variable][element]){
chaine.push([perso])
        }
    }
}
function getRandomInt(max) {
    return Math.floor(Math.random() * max);
}
length = chaine.length
var nb = getRandomInt(length)

console.log("<img url=" + chaine[nb][2] + ">")
document.getElementById("testing").innerHTML = '<img src=' + chaine[nb][0][2] + '>';




